[MyPatient]: StructureDefinition-MyPatient.html
[PatientExample]: Patient-PatientExample.html